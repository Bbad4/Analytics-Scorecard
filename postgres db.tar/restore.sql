--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_India.1252';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: week1; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.week1 (
    name character varying,
    test integer DEFAULT 0,
    assignment integer DEFAULT 0,
    behaviour integer DEFAULT 0,
    communication integer DEFAULT 0,
    participation integer DEFAULT 0
);


ALTER TABLE public.week1 OWNER TO postgres;

--
-- Name: week2; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.week2 (
    name character varying,
    test integer DEFAULT 0,
    assignment integer DEFAULT 0,
    behaviour integer DEFAULT 0,
    communication integer DEFAULT 0,
    participation integer DEFAULT 0
);


ALTER TABLE public.week2 OWNER TO postgres;

--
-- Name: week3; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.week3 (
    name character varying,
    test integer DEFAULT 0,
    assignment integer DEFAULT 0,
    behaviour integer DEFAULT 0,
    communication integer DEFAULT 0,
    participation integer DEFAULT 0
);


ALTER TABLE public.week3 OWNER TO postgres;

--
-- Name: week4; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.week4 (
    name character varying,
    test integer DEFAULT 0,
    assignment integer DEFAULT 0,
    behaviour integer DEFAULT 0,
    communication integer DEFAULT 0,
    participation integer DEFAULT 0
);


ALTER TABLE public.week4 OWNER TO postgres;

--
-- Name: week5; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.week5 (
    name character varying,
    test integer DEFAULT 0,
    assignment integer DEFAULT 0,
    behaviour integer DEFAULT 0,
    communication integer DEFAULT 0,
    participation integer DEFAULT 0
);


ALTER TABLE public.week5 OWNER TO postgres;

--
-- Name: week6; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.week6 (
    name character varying,
    test integer DEFAULT 0,
    assignment integer DEFAULT 0,
    behaviour integer DEFAULT 0,
    communication integer DEFAULT 0,
    participation integer DEFAULT 0
);


ALTER TABLE public.week6 OWNER TO postgres;

--
-- Name: week7; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.week7 (
    name character varying,
    test integer DEFAULT 0,
    assignment integer DEFAULT 0,
    behaviour integer DEFAULT 0,
    communication integer DEFAULT 0,
    participation integer DEFAULT 0
);


ALTER TABLE public.week7 OWNER TO postgres;

--
-- Name: week8; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.week8 (
    name character varying,
    test integer DEFAULT 0,
    assignment integer DEFAULT 0,
    behaviour integer DEFAULT 0,
    communication integer DEFAULT 0,
    participation integer DEFAULT 0
);


ALTER TABLE public.week8 OWNER TO postgres;

--
-- Name: assignments; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.assignments AS
 SELECT COALESCE(w1.name, w2.name, w3.name, w4.name, w5.name, w6.name, w7.name, w8.name) AS name,
    COALESCE(w1.assignment, 0) AS assignment1,
    COALESCE(w2.assignment, 0) AS assignment2,
    COALESCE(w3.assignment, 0) AS assignment3,
    COALESCE(w4.assignment, 0) AS assignment4,
    COALESCE(w5.assignment, 0) AS assignment5,
    COALESCE(w6.assignment, 0) AS assignment6,
    COALESCE(w7.assignment, 0) AS assignment7,
    COALESCE(w8.assignment, 0) AS assignment8
   FROM (((((((public.week1 w1
     FULL JOIN public.week2 w2 ON (((w2.name)::text = (w1.name)::text)))
     FULL JOIN public.week3 w3 ON (((w3.name)::text = (w1.name)::text)))
     FULL JOIN public.week4 w4 ON (((w4.name)::text = (w1.name)::text)))
     FULL JOIN public.week5 w5 ON (((w5.name)::text = (w1.name)::text)))
     FULL JOIN public.week6 w6 ON (((w6.name)::text = (w1.name)::text)))
     FULL JOIN public.week7 w7 ON (((w7.name)::text = (w1.name)::text)))
     FULL JOIN public.week8 w8 ON (((w8.name)::text = (w1.name)::text)));


ALTER TABLE public.assignments OWNER TO postgres;

--
-- Name: behaviours; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.behaviours AS
 SELECT COALESCE(w1.name, w2.name, w3.name, w4.name, w5.name, w6.name, w7.name, w8.name) AS name,
    COALESCE(w1.behaviour, 0) AS behaviour1,
    COALESCE(w2.behaviour, 0) AS behaviour2,
    COALESCE(w3.behaviour, 0) AS behaviour3,
    COALESCE(w4.behaviour, 0) AS behaviour4,
    COALESCE(w5.behaviour, 0) AS behaviour5,
    COALESCE(w6.behaviour, 0) AS behaviour6,
    COALESCE(w7.behaviour, 0) AS behaviour7,
    COALESCE(w8.behaviour, 0) AS behaviour8
   FROM (((((((public.week1 w1
     FULL JOIN public.week2 w2 ON (((w2.name)::text = (w1.name)::text)))
     FULL JOIN public.week3 w3 ON (((w3.name)::text = (w1.name)::text)))
     FULL JOIN public.week4 w4 ON (((w4.name)::text = (w1.name)::text)))
     FULL JOIN public.week5 w5 ON (((w5.name)::text = (w1.name)::text)))
     FULL JOIN public.week6 w6 ON (((w6.name)::text = (w1.name)::text)))
     FULL JOIN public.week7 w7 ON (((w7.name)::text = (w1.name)::text)))
     FULL JOIN public.week8 w8 ON (((w8.name)::text = (w1.name)::text)));


ALTER TABLE public.behaviours OWNER TO postgres;

--
-- Name: communications; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.communications AS
 SELECT COALESCE(w1.name, w2.name, w3.name, w4.name, w5.name, w6.name, w7.name, w8.name) AS name,
    COALESCE(w1.communication, 0) AS communication1,
    COALESCE(w2.communication, 0) AS communication2,
    COALESCE(w3.communication, 0) AS communication3,
    COALESCE(w4.communication, 0) AS communication4,
    COALESCE(w5.communication, 0) AS communication5,
    COALESCE(w6.communication, 0) AS communication6,
    COALESCE(w7.communication, 0) AS communication7,
    COALESCE(w8.communication, 0) AS communication8
   FROM (((((((public.week1 w1
     FULL JOIN public.week2 w2 ON (((w2.name)::text = (w1.name)::text)))
     FULL JOIN public.week3 w3 ON (((w3.name)::text = (w1.name)::text)))
     FULL JOIN public.week4 w4 ON (((w4.name)::text = (w1.name)::text)))
     FULL JOIN public.week5 w5 ON (((w5.name)::text = (w1.name)::text)))
     FULL JOIN public.week6 w6 ON (((w6.name)::text = (w1.name)::text)))
     FULL JOIN public.week7 w7 ON (((w7.name)::text = (w1.name)::text)))
     FULL JOIN public.week8 w8 ON (((w8.name)::text = (w1.name)::text)));


ALTER TABLE public.communications OWNER TO postgres;

--
-- Name: participations; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.participations AS
 SELECT COALESCE(w1.name, w2.name, w3.name, w4.name, w5.name, w6.name, w7.name, w8.name) AS name,
    COALESCE(w1.participation, 0) AS participation1,
    COALESCE(w2.participation, 0) AS participation2,
    COALESCE(w3.participation, 0) AS participation3,
    COALESCE(w4.participation, 0) AS participation4,
    COALESCE(w5.participation, 0) AS participation5,
    COALESCE(w6.participation, 0) AS participation6,
    COALESCE(w7.participation, 0) AS participation7,
    COALESCE(w8.participation, 0) AS participation8
   FROM (((((((public.week1 w1
     FULL JOIN public.week2 w2 ON (((w2.name)::text = (w1.name)::text)))
     FULL JOIN public.week3 w3 ON (((w3.name)::text = (w1.name)::text)))
     FULL JOIN public.week4 w4 ON (((w4.name)::text = (w1.name)::text)))
     FULL JOIN public.week5 w5 ON (((w5.name)::text = (w1.name)::text)))
     FULL JOIN public.week6 w6 ON (((w6.name)::text = (w1.name)::text)))
     FULL JOIN public.week7 w7 ON (((w7.name)::text = (w1.name)::text)))
     FULL JOIN public.week8 w8 ON (((w8.name)::text = (w1.name)::text)));


ALTER TABLE public.participations OWNER TO postgres;

--
-- Name: tests; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.tests AS
 SELECT COALESCE(w1.name, w2.name, w3.name, w4.name, w5.name, w6.name, w7.name, w8.name) AS name,
    COALESCE(w1.test, 0) AS test1,
    COALESCE(w2.test, 0) AS test2,
    COALESCE(w3.test, 0) AS test3,
    COALESCE(w4.test, 0) AS test4,
    COALESCE(w5.test, 0) AS test5,
    COALESCE(w6.test, 0) AS test6,
    COALESCE(w7.test, 0) AS test7,
    COALESCE(w8.test, 0) AS test8
   FROM (((((((public.week1 w1
     FULL JOIN public.week2 w2 ON (((w2.name)::text = (w1.name)::text)))
     FULL JOIN public.week3 w3 ON (((w3.name)::text = (w1.name)::text)))
     FULL JOIN public.week4 w4 ON (((w4.name)::text = (w1.name)::text)))
     FULL JOIN public.week5 w5 ON (((w5.name)::text = (w1.name)::text)))
     FULL JOIN public.week6 w6 ON (((w6.name)::text = (w1.name)::text)))
     FULL JOIN public.week7 w7 ON (((w7.name)::text = (w1.name)::text)))
     FULL JOIN public.week8 w8 ON (((w8.name)::text = (w1.name)::text)));


ALTER TABLE public.tests OWNER TO postgres;

--
-- Name: parameters; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.parameters AS
 WITH cte1 AS (
         SELECT COALESCE(t.name, a.name, b.name, c.name, p.name) AS name,
            (((((((t.test1 + t.test2) + t.test3) + t.test4) + t.test5) + t.test6) + t.test7) + t.test8) AS test_total,
            (((((((a.assignment1 + a.assignment2) + a.assignment3) + a.assignment4) + a.assignment5) + a.assignment6) + a.assignment7) + a.assignment8) AS assignment_total,
            (((((((b.behaviour1 + b.behaviour2) + b.behaviour3) + b.behaviour4) + b.behaviour5) + b.behaviour6) + b.behaviour7) + b.behaviour8) AS behaviour_total,
            (((((((c.communication1 + c.communication2) + c.communication3) + c.communication4) + c.communication5) + c.communication6) + c.communication7) + c.communication8) AS communication_total,
            (((((((p.participation1 + p.participation2) + p.participation3) + p.participation4) + p.participation5) + p.participation6) + p.participation7) + p.participation8) AS participation_total
           FROM ((((public.tests t
             FULL JOIN public.assignments a ON (((a.name)::text = (t.name)::text)))
             FULL JOIN public.behaviours b ON (((b.name)::text = (t.name)::text)))
             FULL JOIN public.communications c ON (((c.name)::text = (t.name)::text)))
             FULL JOIN public.participations p ON (((p.name)::text = (t.name)::text)))
        ), cte2 AS (
         SELECT cte1.name,
            cte1.test_total,
            cte1.assignment_total,
            cte1.behaviour_total,
            cte1.communication_total,
            cte1.participation_total,
            ((((cte1.test_total + cte1.assignment_total) + cte1.behaviour_total) + cte1.communication_total) + cte1.participation_total) AS parameters_total
           FROM cte1
        )
 SELECT cte2.name,
    cte2.test_total,
    cte2.assignment_total,
    cte2.behaviour_total,
    cte2.communication_total,
    cte2.participation_total,
    cte2.parameters_total
   FROM cte2;


ALTER TABLE public.parameters OWNER TO postgres;

--
-- Data for Name: week1; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.week1 (name, test, assignment, behaviour, communication, participation) FROM stdin;
\.
COPY public.week1 (name, test, assignment, behaviour, communication, participation) FROM '$$PATH$$/3401.dat';

--
-- Data for Name: week2; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.week2 (name, test, assignment, behaviour, communication, participation) FROM stdin;
\.
COPY public.week2 (name, test, assignment, behaviour, communication, participation) FROM '$$PATH$$/3402.dat';

--
-- Data for Name: week3; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.week3 (name, test, assignment, behaviour, communication, participation) FROM stdin;
\.
COPY public.week3 (name, test, assignment, behaviour, communication, participation) FROM '$$PATH$$/3403.dat';

--
-- Data for Name: week4; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.week4 (name, test, assignment, behaviour, communication, participation) FROM stdin;
\.
COPY public.week4 (name, test, assignment, behaviour, communication, participation) FROM '$$PATH$$/3404.dat';

--
-- Data for Name: week5; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.week5 (name, test, assignment, behaviour, communication, participation) FROM stdin;
\.
COPY public.week5 (name, test, assignment, behaviour, communication, participation) FROM '$$PATH$$/3405.dat';

--
-- Data for Name: week6; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.week6 (name, test, assignment, behaviour, communication, participation) FROM stdin;
\.
COPY public.week6 (name, test, assignment, behaviour, communication, participation) FROM '$$PATH$$/3406.dat';

--
-- Data for Name: week7; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.week7 (name, test, assignment, behaviour, communication, participation) FROM stdin;
\.
COPY public.week7 (name, test, assignment, behaviour, communication, participation) FROM '$$PATH$$/3407.dat';

--
-- Data for Name: week8; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.week8 (name, test, assignment, behaviour, communication, participation) FROM stdin;
\.
COPY public.week8 (name, test, assignment, behaviour, communication, participation) FROM '$$PATH$$/3408.dat';

--
-- PostgreSQL database dump complete
--

